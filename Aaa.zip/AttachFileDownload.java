package com.servlet;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.service.log.DWAFLog;
import com.util.common.StringUtil;
import fowave.com.attach.AttachFileTask;
import fowave.com.attach.AttachFileVo;
//import SCSL.*;

/**
 * Servlet implementation class AttachFileDownload
 */
public class AttachFileDownload extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private int seq = 0;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AttachFileDownload() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		downloadFile(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		downloadFile(request, response);
	}

	private void downloadFile(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		FileInputStream fis = null;
		BufferedInputStream fin = null;
		BufferedOutputStream outs = null;
		File file = null;
		try {
			byte[] buf = new byte[8 * 1024];

			this.seq = Integer
					.parseInt(StringUtil.isEmpty(request.getParameter("seq")) ? "0" : request.getParameter("seq"));

			AttachFileTask upTask = new AttachFileTask();
			AttachFileVo vo = upTask.getFileInfo(this.seq);

			String downloadFileName = vo.getLocalFileName();

			downloadFileName = URLEncoder.encode(downloadFileName, "UTF-8");
			downloadFileName = downloadFileName.replaceAll("\\+", "%20");

			String mimetype = request.getSession().getServletContext().getMimeType(downloadFileName);

			response.reset();

			String CHARSET = "UTF-8";
			if ((mimetype == null) || (mimetype.length() == 0)) {
				response.setContentType("Content-type: application/octet-stream;charset=" + CHARSET);
			} else {
				response.setContentType("Content-type: application/x-msdownload;charset=" + CHARSET);
			}

			response.setHeader("Content-Disposition",
					"attachment; filename=" + new String(downloadFileName.getBytes(), "8859_1").toString() + ";");
			response.setHeader("Content-Transfer-Encoding", "binary");

			//SLDsFile sFile = new SLDsFile();
			//sFile.SettingPathForProperty("/fsutil/softcamp/02_Module/02_ServiceLinker/softcamp.properties");

			String drmFilePath = vo.getServerFilePath() + vo.getServerFileName();
			String filePath = vo.getServerFilePath() + "_" + vo.getServerFileName();
			
			//10.224.51.
			//10.224.52.
			String userIp = request.getRemoteAddr();
			int idx = userIp.lastIndexOf(".");
			String ip = userIp.substring(0, idx+1);
			
//			if(ip.equals("10.224.51.") || ip.equals("10.224.52.")) 
//			{
//				int retVal = sFile.CreateDecryptFileDAC("/fsutil/softcamp/04_KeyFile/keyDAC_SVR0.sc", "SECURITYDOMAIN",
//						drmFilePath, filePath);
//			}
//			else
//			{
				filePath = drmFilePath;
//			}
			

			//System.out.println(" CreateDecryptFileDAC [" + retVal + "]");

			file = new File(filePath);

			fin = new BufferedInputStream(new FileInputStream(filePath));
			outs = new BufferedOutputStream(response.getOutputStream());
			int read = 0;
			while ((read = fin.read(buf)) != -1) {
				outs.write(buf, 0, read);
				outs.flush();
			}
		} catch (Exception ex) {
			DWAFLog.errLogger.error("[" + this.getClass().getName() + "]:" + ex.toString(), ex);
			response.sendRedirect("/jsp/common/download/FileDownload_Error.jsp");

			DWAFLog.errLogger.error("[" + getClass().getName() + "]:" + ex.toString(), ex);
		} finally {
			if (outs != null) {
				outs.close();
			}
			if (fis != null) {
				fis.close();
			}
		}
	}

}
